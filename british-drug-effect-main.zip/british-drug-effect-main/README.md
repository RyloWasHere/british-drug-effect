# british-drug-effect

This is a brtish drug effect with alot of UK type drug names

requirements - https://github.com/RS7x/mythic_notify
